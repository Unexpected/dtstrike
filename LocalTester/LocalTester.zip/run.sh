java -jar LocalTester.jar
