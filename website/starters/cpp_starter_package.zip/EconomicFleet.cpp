#include "EconomicFleet.h"


EconomicFleet::EconomicFleet(int owner, int numShips, int sourcePlanet, int destPlanet,
			     int totalTripLength, int turnsRemaining) :
	Fleet(owner, numShips, sourcePlanet, destPlanet, totalTripLength, turnsRemaining)
{
}
