#include "MilitaryPlanet.h"


MilitaryPlanet::MilitaryPlanet(int id, int owner, int numShips, double x, double y) :
	Planet(id, owner, numShips, x, y)
{
}
