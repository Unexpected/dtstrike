GO Starter Package by Kevin Lansard

Your starting point for improving this startup bot is by modifying 
- MyFirstBot.go : the main algorythm is there
- GameState.go : the main data structure is there.
- PlanetSystem.go : Structures for planet, Lists of planets and fleets
- Main.go : is doing all the boilerplate work for you ! No need to change that.

To build properly this bot on your desktop :
Install GO : http://golang.org/
import the bot into $GOPATH\src\main\

If you need to have a little help here is also the full goclipse workspace :
then install goeclipse : https://code.google.com/p/goclipse/ and import bot into $GOPATH\src\main\
do not forget to set the GOPATH value !

if you need pointer in how to develop with GO, here are some good starting point :
- http://golang.org/
- http://www.golang-book.com/
- https://code.google.com/p/go-wiki/wiki/Projects
- contact me
