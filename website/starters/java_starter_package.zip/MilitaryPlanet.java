public class MilitaryPlanet extends Planet {

	public MilitaryPlanet(int id, int owner, int numShips, double x, double y) {
		super(id, owner, numShips, x, y);
	}

}
