
public class MilitaryFleet extends Fleet {

	public MilitaryFleet(int owner, int numEngineers, int sourceDept,
			int destDept, int tripLength, int turnsRemaining) {
		super(owner, numEngineers, sourceDept, destDept, tripLength, turnsRemaining);
	}

}
