public class Planet {

	public int id;
	public int owner;
	public int numShips;
	public double x;
	public double y;

	public Planet(int id, int owner, int numShips, double x, double y) {
		this.id = id;
		this.owner = owner;
		this.numShips = numShips;
		this.x = x;
		this.y = y;
	}

}
