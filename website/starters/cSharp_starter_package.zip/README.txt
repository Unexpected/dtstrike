Sources are in the src folder. 

Implementation should be done in MyBot.cs
